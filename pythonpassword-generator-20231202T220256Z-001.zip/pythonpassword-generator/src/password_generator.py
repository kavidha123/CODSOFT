import random
import string

def generate_password(length, complexity):
    if complexity < 1 or complexity > 4:
        raise ValueError("Complexity must be between 1 and 4.")
    
    characters = string.ascii_lowercase
    if complexity >= 2:
        characters += string.ascii_uppercase
    if complexity >= 3:
        characters += string.digits
    if complexity >= 4:
        characters += string.punctuation

    return ''.join(random.choice(characters) for i in range(length))

