import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import random
import string

# Function to generate a random password
def generate_password(length, complexity=4):
    characters = string.ascii_lowercase
    if complexity >= 2:
        characters += string.ascii_uppercase
    if complexity >= 3:
        characters += string.digits
    if complexity >= 4:
        characters += string.punctuation

    return ''.join(random.choice(characters) for i in range(length))

# Function called when 'Generate Password' button is clicked
def on_generate_clicked():
    try:
        password_length = int(length_entry.get())
        if password_length < 6 or password_length > 128:
            messagebox.showerror("Invalid Length", "Password length must be between 6 and 128.")
            return
        generated_password = generate_password(password_length)
        password_entry.delete(0, tk.END)
        password_entry.insert(0, generated_password)
    except ValueError:
        messagebox.showerror("Invalid Input", "Please enter a valid number for password length.")

# Function called when 'Accept' button is clicked
def on_accept_clicked():
    user = user_name_entry.get()
    password = password_entry.get()
    messagebox.showinfo("Accepted", f"Password for {user} accepted and saved.")

# Function called when 'Reset' button is clicked
def on_reset_clicked():
    user_name_entry.delete(0, tk.END)
    length_entry.delete(0, tk.END)
    password_entry.delete(0, tk.END)

# Set up the main window
root = tk.Tk()
root.title("Password Generator")
root.configure(bg='green')  # Set the background color to green

# Load and set the background image
background_image_path = 'images/asdf.png'  # Make sure to use the correct path to your background image
background_image = Image.open(background_image_path)
background_photo = ImageTk.PhotoImage(background_image)
background_label = tk.Label(root, image=background_photo)
background_label.place(relwidth=1, relheight=1)

# Create a frame to contain the widgets with dark green background
frame = tk.Frame(root, bg='#013220')  # Dark green color
frame.place(relx=0.5, rely=0.5, relwidth=0.4, relheight=0.4, anchor='center')

# Widgets for user input
tk.Label(frame, text="Enter user name:", bg='#013220', fg='white').pack()
user_name_entry = tk.Entry(frame)
user_name_entry.pack()

tk.Label(frame, text="Enter password length:", bg='#013220', fg='white').pack()
length_entry = tk.Entry(frame)
length_entry.pack()

# Entry widget to display the generated password
tk.Label(frame, text="Generated password:", bg='#013220', fg='white').pack()
password_entry = tk.Entry(frame)
password_entry.pack()

# Button to generate the password
generate_button = tk.Button(frame, text="GENERATE PASSWORD", command=on_generate_clicked)
generate_button.pack(pady=5)

# Buttons frame to control the space between the 'ACCEPT' and 'RESET' buttons
buttons_frame = tk.Frame(frame, bg='#013220')
buttons_frame.pack(fill=tk.X, expand=True)

# 'ACCEPT' button on the left side of the buttons frame
accept_button = tk.Button(buttons_frame, text="ACCEPT", command=on_accept_clicked)
accept_button.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(70, 5))

# 'RESET' button on the right side of the buttons frame
reset_button = tk.Button(buttons_frame, text="RESET", command=on_reset_clicked)
reset_button.pack(side=tk.RIGHT, fill=tk.X, expand=True, padx=(5, 70))

# Run the application
root.mainloop()
